package com.rubix.rubixdemo.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/user")
public class UserController {

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public @ResponseBody String login()
	{
		return "Hello123";
		
	}
	
	
	@RequestMapping(value = "/login1", method = RequestMethod.GET)
	public @ResponseBody String login1()
	{
		String a = "Hello1";
		return a;
		// return "Hello";
		
	}
	
	@RequestMapping(value = "/login2", method = RequestMethod.GET)
	public @ResponseBody String login2()
	{
		String a = "Hello";
		return a;
		// return "Hello";
		
	}
}
